﻿using ApplicacionBancaria.App.presentacion;

Console.WriteLine("program");

presentacion RunView = new presentacion();

